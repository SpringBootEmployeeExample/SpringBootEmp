/*
SQLyog Trial v13.1.8 (64 bit)
MySQL - 8.0.30 : Database - springboot
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`springboot` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `springboot`;

/*Table structure for table `address_example` */

DROP TABLE IF EXISTS `address_example`;

CREATE TABLE `address_example` (
  `address_id` bigint NOT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pin_code` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `address_example` */

insert  into `address_example`(`address_id`,`city`,`pin_code`,`state`) values 
(1,'Pen','402107','Maharashtra'),
(2,'Pune','402001','Maharshtra'),
(31,'Panvel','7766','Maharashtra'),
(32,'Mumbai','6666','Maharshtra');

/*Table structure for table `department_example` */

DROP TABLE IF EXISTS `department_example`;

CREATE TABLE `department_example` (
  `dept_id` bigint NOT NULL,
  `dept_descript` varchar(255) DEFAULT NULL,
  `dept_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `department_example` */

insert  into `department_example`(`dept_id`,`dept_descript`,`dept_name`) values 
(1,'Developed a different types of software','Software Development'),
(2,'Works on Advertisements','Advertise Department'),
(21,'Check a different types of hardware','Hardware Development'),
(22,'Works on Marketing','Marketing Department');

/*Table structure for table `employee_address` */

DROP TABLE IF EXISTS `employee_address`;

CREATE TABLE `employee_address` (
  `employee_id` bigint NOT NULL,
  `address_id` bigint NOT NULL,
  UNIQUE KEY `UK_b9jl6ns5a27q5opwotmlj6fmo` (`address_id`),
  KEY `FKoyjjn5e2kni0bg3bb5amqenyd` (`employee_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `employee_address` */

insert  into `employee_address`(`employee_id`,`address_id`) values 
(1,1),
(1,2),
(3,32),
(3,31);

/*Table structure for table `employee_department` */

DROP TABLE IF EXISTS `employee_department`;

CREATE TABLE `employee_department` (
  `employee_id` bigint NOT NULL,
  `department_id` bigint NOT NULL,
  UNIQUE KEY `UK_svohrfkq53gxurt1snia5cit8` (`department_id`),
  KEY `FKf2162lvpw3m77r4imja6u20a8` (`employee_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `employee_department` */

insert  into `employee_department`(`employee_id`,`department_id`) values 
(1,1),
(1,2),
(3,22),
(3,21);

/*Table structure for table `employee_example` */

DROP TABLE IF EXISTS `employee_example`;

CREATE TABLE `employee_example` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `birthdate` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `employee_example` */

insert  into `employee_example`(`id`,`birthdate`,`name`,`surname`) values 
(1,'2022-09-14','Aniket','Vaishampayan'),
(3,'2022-09-12','Ahilyaa','Dixit');

/*Table structure for table `employee_skill` */

DROP TABLE IF EXISTS `employee_skill`;

CREATE TABLE `employee_skill` (
  `employee_id` bigint NOT NULL,
  `skill_id` bigint NOT NULL,
  UNIQUE KEY `UK_eaonb94ovmqv5ry6aogkkjp9g` (`skill_id`),
  KEY `FKj4iea3p5r4q6h9sg1r59ccmms` (`employee_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `employee_skill` */

insert  into `employee_skill`(`employee_id`,`skill_id`) values 
(1,1),
(1,2),
(3,42),
(3,41);

/*Table structure for table `skill_example` */

DROP TABLE IF EXISTS `skill_example`;

CREATE TABLE `skill_example` (
  `sid` bigint NOT NULL,
  `sdescript` varchar(255) DEFAULT NULL,
  `sname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `skill_example` */

insert  into `skill_example`(`sid`,`sdescript`,`sname`) values 
(1,'To developed java based software','Full Stack Java Developer'),
(2,'Working on any type of database','DBA'),
(41,'To work networking based software','Full Stack CCNA Developer'),
(42,'Cloud Computing database','Hadoop Admin');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
