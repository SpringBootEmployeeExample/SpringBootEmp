package com.springboot.application.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.springboot.application.dto.EmployeeRequest;
import com.springboot.application.exception.ResourceNotFoundException;
import com.springboot.application.model.Address;
import com.springboot.application.model.Department;
import com.springboot.application.model.Employee;
import com.springboot.application.model.Skill;
import com.springboot.application.repository.AddressRepository;
import com.springboot.application.repository.DepartmentRepository;
import com.springboot.application.repository.EmployeeRepository;
import com.springboot.application.repository.SkillRepository;

@RestController
public class EmployeeController {

	@Autowired
	public EmployeeRepository employeeRepository;
	@Autowired
	public AddressRepository addressRepository;
	@Autowired
	public SkillRepository skillRepository;
	@Autowired
	public DepartmentRepository departmentRepository;

	@PostMapping("/save")
	public Employee createEmployee(@RequestBody EmployeeRequest request) {
		return employeeRepository.save(request.getEmployee());
	}

	@GetMapping("/listAll")
	public List<Employee> listofAllData() {
		return employeeRepository.findAll();
	}

	@GetMapping("/listById/{employeeId}")
	public Employee getEmployeeById(@PathVariable(value = "employeeId") Long employeeId) {
		return employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "employeeId", employeeId));
	}

	@DeleteMapping("/deleteById/{employeeId}")
	public ResponseEntity<?> deleteEmployee(@PathVariable(value = "employeeId") Long employeeId) {
		Employee employee = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "employeeId", employeeId));
		employeeRepository.delete(employee);
		return ResponseEntity.ok().build();
	}

	@PutMapping("/updateById/{employeeId}")
	public Employee updateEmployee(@PathVariable(value = "employeeId") Long employeeId,
			@RequestBody Employee employeeDetails) {

		Employee employee = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee", "employeeId", employeeId));

		long empid = employeeDetails.getEmployeeId();
		String name = employeeDetails.getFirstName();
		String surname = employeeDetails.getLastName();
		Date birthdate = employeeDetails.getDob();

		employee.setEmployeeId(empid);
		employee.setFirstName(name);
		employee.setLastName(surname);
		employee.setDob(birthdate);

		Department department = new Department();
		long departmentId = department.getDepartmentId();
		String departmentName = department.getDepartmentName();
		String departmentDescription = department.getDepartmentDescription();

		department.setDepartmentId(departmentId);
		department.setDepartmentName(departmentName);
		department.setDepartmentDescription(departmentDescription);

		List<Department> list_departments = employeeDetails.getDepartments();
		list_departments.add(department);
		employee.setDepartments(list_departments);

		Address address = new Address();
		long addressId = address.getAddressId();
		String state = address.getState();
		String city = address.getCity();
		String pincode = address.getPincode();

		address.setAddressId(addressId);
		address.setState(state);
		address.setCity(city);
		address.setPincode(pincode);

		List<Address> list_addressess = employeeDetails.getAddressess();
		list_addressess.add(address);
		employee.setAddressess(list_addressess);

		Skill skill = new Skill();
		long skillId = skill.getSkillId();
		String skillName = skill.getSkillName();
		String skillDescription = skill.getSkillDescription();

		skill.setSkillId(skillId);
		skill.setSkillName(skillName);
		skill.setSkillDescription(skillDescription);

		List<Skill> list_skills = employeeDetails.getSkills();
		list_skills.add(skill);
		employee.setSkills(list_skills);

		Employee updatedComment = employeeRepository.save(employee);
		return updatedComment;
	}

}
