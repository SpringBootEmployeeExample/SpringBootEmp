package com.springboot.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmployeeDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployeeDemoApplication.class, args);
		System.out.println("SpringBoot Started...");
	}
}
