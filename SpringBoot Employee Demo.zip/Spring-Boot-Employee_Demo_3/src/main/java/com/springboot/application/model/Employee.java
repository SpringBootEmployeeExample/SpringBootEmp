package com.springboot.application.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Employee_Example")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	public long employeeId;
	@Column(name = "NAME")
	public String firstName;
	@Column(name = "SURNAME")
	public String lastName;
	@Temporal(TemporalType.DATE)
	@Column(name = "BIRTHDATE")
	public Date dob;
	@OneToMany(cascade = CascadeType.ALL, targetEntity = Department.class)
	@JoinTable(name = "Employee_Department", joinColumns = { @JoinColumn(name = "EmployeeId") }, inverseJoinColumns = {
			@JoinColumn(name = "DepartmentId") })
	public List<Department> departments = new ArrayList<>();
	@OneToMany(cascade = CascadeType.ALL, targetEntity = Address.class)
	@JoinTable(name = "Employee_Address", joinColumns = { @JoinColumn(name = "EmployeeId") }, inverseJoinColumns = {
			@JoinColumn(name = "AddressId") })
	public List<Address> addressess = new ArrayList<>();
	@OneToMany(cascade = CascadeType.ALL, targetEntity = Skill.class)
	@JoinTable(name = "Employee_Skill", joinColumns = { @JoinColumn(name = "EmployeeId") }, inverseJoinColumns = {
			@JoinColumn(name = "SkillId") })
	public List<Skill> Skills = new ArrayList<>();

	public long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public List<Department> getDepartments() {
		return departments;
	}

	public void setDepartments(List<Department> departments) {
		this.departments = departments;
	}

	public List<Address> getAddressess() {
		return addressess;
	}

	public void setAddressess(List<Address> addressess) {
		this.addressess = addressess;
	}

	public List<Skill> getSkills() {
		return Skills;
	}

	public void setSkills(List<Skill> skills) {
		Skills = skills;
	}

}
