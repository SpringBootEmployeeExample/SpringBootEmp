package com.springboot.application.dto;

import com.springboot.application.model.Employee;

public class EmployeeRequest {
	public Employee employee;

	public EmployeeRequest() {
		super();
	}

	public EmployeeRequest(Employee employee) {
		super();
		this.employee = employee;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
}
