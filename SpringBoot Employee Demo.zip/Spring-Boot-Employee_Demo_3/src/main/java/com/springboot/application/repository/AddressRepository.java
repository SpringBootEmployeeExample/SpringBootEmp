package com.springboot.application.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.application.model.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {

}
